// Jewelia England
// CS 499 
// Artifact # 1 Software design and Engineering

// Imports
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;

// Bank Application Class
public class BankApplication extends JFrame {

	// Private class variables
    private float monthlyDeposit;
    private float annualInterest;
    private int numberYears;
    private float interestRate;
    private float premiumInterestRate;
    private float openingAmount;
    private float interest;

    private JTextArea textArea;


    public void plotGraphs(DefaultCategoryDataset monthlyInterestWithDepositData, DefaultCategoryDataset balanceWithDepositsData, DefaultCategoryDataset monthlyInterestWithNoDepositData, DefaultCategoryDataset balanceWithNoDepositsData) {

    	// Monthly interest with monthly payments graph
        JFreeChart monthlyInterestWithDepositChart = ChartFactory.createLineChart(
                "Annual Interest Over Months With Deposits",   // graph title
                "Month",                         // x axis label
                "Monthly Interest ($)",          // y axis label
                monthlyInterestWithDepositData,  // interest data
                PlotOrientation.VERTICAL,        // graph orientation
                true,                          
                true,                          
                false                         
        );
        
        // Monthly balance with monthly payments graph
        JFreeChart balanceWithDepositsChart = ChartFactory.createLineChart(
                "Monthly Closing Balance Over Time With Deposits",    // chart title
                "Month",                                // domain axis label
                "Closing Balance ($)",                  // range axis label
                balanceWithDepositsData,                // balance data
                PlotOrientation.VERTICAL,               // graph orientation
                true,                                   
                true,                                   
                false                                   
        );
        // Monthly interest with monthly payments graph
        JFreeChart monthlyInterestWithNoDepositChart = ChartFactory.createLineChart(
                "Annual Interest Over Months With No Deposits",   // graph title
                "Month",                         // x axis label
                "Monthly Interest ($)",          // y axis label
                monthlyInterestWithNoDepositData,  // interest data
                PlotOrientation.VERTICAL,        // graph orientation
                true,                          
                true,                          
                false                         
        );
        
        // Monthly balance with monthly payments graph
        JFreeChart balancesWithNoDepositsChart = ChartFactory.createLineChart(
                "Monthly Closing Balance Over Time With No Deposits",    // chart title
                "Month",                                // domain axis label
                "Closing Balance ($)",                  // range axis label
                balanceWithNoDepositsData,                // balance data
                PlotOrientation.VERTICAL,               // graph orientation
                true,                                   
                true,                                   
                false                                   
        );


       // Create chart panels and add charts to the panels
        ChartPanel monthlyInterestWithDepositsChartPanel = new ChartPanel(monthlyInterestWithDepositChart);
        monthlyInterestWithDepositsChartPanel.setPreferredSize(new Dimension(1200, 500));
        ChartPanel balanceWithDepositsChartPanel = new ChartPanel(balanceWithDepositsChart);
        balanceWithDepositsChartPanel.setPreferredSize(new Dimension(1200, 500));
        ChartPanel monthlyInterestWithNoDepositsChartPanel = new ChartPanel(monthlyInterestWithNoDepositChart);
        monthlyInterestWithDepositsChartPanel.setPreferredSize(new Dimension(1200, 500));
        ChartPanel balanceWithNoDepositsChartPanel = new ChartPanel(balancesWithNoDepositsChart);
        balanceWithDepositsChartPanel.setPreferredSize(new Dimension(1200, 500));

        JFrame graphFrame = new JFrame("Graphs");
        graphFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        graphFrame.setLayout(new GridLayout(2, 1));
        graphFrame.getContentPane().add(monthlyInterestWithDepositsChartPanel);
        graphFrame.getContentPane().add(monthlyInterestWithNoDepositsChartPanel);
        graphFrame.getContentPane().add(balanceWithDepositsChartPanel);
        graphFrame.getContentPane().add(balanceWithNoDepositsChartPanel);
        graphFrame.pack();
        graphFrame.setVisible(true);
    }
    
    // Getters and Setters

    // Get monthly amount
    public float getMonthlyDeposit() {
        return monthlyDeposit;
    }

    // Get initial deposit amount
    public float getAnnualInterest() {
        return annualInterest;
    }

    // Get number of years
    public int getNumberYears() {
        return numberYears;
    }

    // Get interest rate
    public float getInterestRate() {
        return interestRate;
    }

    // Get premium interest rate
    public float getPremiumInterestRate() {
        return premiumInterestRate;
    }

    // Get opening amount
    public float getOpeningAmount() {
        return openingAmount;
    }
    
    // Set monthly deposit
    public void setMonthlyDeposit(float monthlyDeposit) {
        this.monthlyDeposit = monthlyDeposit;
    }
    
    // Set annual interest
    public void setAnnualInterest(float annualInterest) {
        this.annualInterest = annualInterest;
    }
    
    // set interest rate
    public void setInterestRate(float interestRate) {
        this.interestRate = interestRate;
    }
    
    // Set premium Interest Rate
    public void setPremiumInterestRate(float premiumInterestRate) {
        this.premiumInterestRate = premiumInterestRate;
    }
    // Set opening amount
    public void setOpeningAmount(float openingAmount) {
        this.openingAmount = openingAmount;
    }
    
    // set number of years
    void setNumberYears(int numberYears) {
        this.numberYears = numberYears;
    }
    
    // Calculate interest
    public float calculateInterest() {
        interest = (openingAmount + monthlyDeposit) * ((interestRate + premiumInterestRate) / 100 / 12);
        return roundFloat(interest);
    }
    
    // Rounds up
    public float roundFloat(float num) {
        float value = (int) (num * 100 + 0.5);
        return ((float) value / 100);
    }

    // Main entry point function
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BankApplication bankApplication = new BankApplication();
            bankApplication.buildAppGUI();
        });
    }

    private void buildAppGUI() {
    	// Create the main frame
        JFrame mainFrame = new JFrame("Bank Application");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(800, 500);
        mainFrame.setLayout(new BorderLayout());

        // Create the text area for output
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Create the input panel
        JPanel inputPanel = new JPanel(new GridLayout(7, 2));
        
        // Create text labels and fields and submit button for the input panel
        JLabel initialDepositLabel = new JLabel("Initial Investment Amount:");
        JTextField initialDepositField = new JTextField();
        JLabel monthlyDepositLabel = new JLabel("Monthly Deposit:");
        JTextField monthlyDepositField = new JTextField();
        JLabel interestRateLabel = new JLabel("Annual interest (%):");
        JTextField interestRateField = new JTextField();
        JLabel premiumInterestRateLabel = new JLabel("Premium interest (%):");
        JTextField premiumInterestRateField = new JTextField();
        JLabel numberYearsLabel = new JLabel("Number of years:");
        JTextField numberYearsField = new JTextField();
        JButton submitButton = new JButton("Submit");
        
        // Action Listener for the "Submit" button
        submitButton.addActionListener(event -> {
            String initialInvestmentAmount = initialDepositField.getText().replace("$", "");
            String monthlyDeposit = monthlyDepositField.getText().replace("$", "");
            String interestRate = interestRateField.getText().replace("%", "");
            String premiumInterestRate = premiumInterestRateField.getText().replace("%", "");
            int numberYears = Integer.parseInt(numberYearsField.getText());

            setOpeningAmount(roundFloat(Float.parseFloat(initialInvestmentAmount)));
            setMonthlyDeposit(Float.parseFloat(monthlyDeposit));
            setInterestRate(Float.parseFloat(interestRate));
            setPremiumInterestRate(Float.parseFloat(premiumInterestRate));
            setNumberYears(numberYears);

            calculateInterest();

            // JFreeChart data sets
            DefaultCategoryDataset monthlyInterestWithDepositDataset = new DefaultCategoryDataset();
            DefaultCategoryDataset balanceWithDepositDataset = new DefaultCategoryDataset();
            DefaultCategoryDataset monthlyInterestWithNoDepositDataset = new DefaultCategoryDataset();
            DefaultCategoryDataset balanceWithNoDepositDataset = new DefaultCategoryDataset();
            float initialOpeningAmount = getOpeningAmount();

            // Calculate the balance and interest with no monthly payments
            StringBuilder output = new StringBuilder();
            output.append("Balance and Interest without Monthly deposit\n");
            for (int i = 0; i < numberYears * 12; i++) {
                float interest = calculateInterest();
                float closingBalance = getOpeningAmount() + interest;
                output.append(String.format("Month %d  OpeningAmount $%.2f  Total $%.2f  Interest $%.2f  Closing Balance $%.2f\n",
                        (i + 1), getOpeningAmount(), getOpeningAmount(), interest, 
                        (getOpeningAmount() + interest)));
                
                // Build up the monthly balance with monthly deposits data set for graphing
                balanceWithNoDepositDataset.addValue(closingBalance, "Closing Balance With No Payments", "Month " + (i + 1));
                
                // Build up the monthly interest with monthly deposits data set for graphing
                monthlyInterestWithNoDepositDataset.addValue(interest, "Interest With No Payments", "Month  " + (i + 1));
                
                setOpeningAmount(getOpeningAmount() + interest);
            }

            output.append("\n\n\n");
            setOpeningAmount(initialOpeningAmount);

            // Calculate the balance and interest with monthly payments
            output.append("Balance and Interest with Monthly deposit\n");
            for (int i = 0; i < numberYears * 12; i++) {
                float interest = calculateInterest();
                float closingBalance = getOpeningAmount() + interest + getMonthlyDeposit();
                output.append(String.format("Month %d  OpeningAmount $%.2f  Deposited Amount $%.2f  Total $%.2f  Interest $%.2f  Closing Balance $%.2f\n",
                        (i + 1), getOpeningAmount(), getMonthlyDeposit(),
                        (getMonthlyDeposit() + getOpeningAmount()), interest, 
                        closingBalance));
                
                // Build up the monthly balance with monthly deposits data set for graphing
                balanceWithDepositDataset.addValue(closingBalance, "Closing Balance With Monthly Payments", "Month " + (i + 1));
                
                // Build up the monthly interest with monthly deposits data set for graphing
                monthlyInterestWithDepositDataset.addValue(interest, "Interest With Monthly Payments", "Month  " + (i + 1));
                
                setOpeningAmount(closingBalance);
            }
          
            // plot the Graphs
            plotGraphs(monthlyInterestWithDepositDataset, balanceWithDepositDataset,monthlyInterestWithNoDepositDataset, balanceWithNoDepositDataset);

            textArea.setText(output.toString());
        });  // Action listener

        // Add text labels and fields and submit button to the input panel
        inputPanel.add(initialDepositLabel);
        inputPanel.add(initialDepositField);
        inputPanel.add(monthlyDepositLabel);
        inputPanel.add(monthlyDepositField);
        inputPanel.add(interestRateLabel);
        inputPanel.add(interestRateField);
        inputPanel.add(premiumInterestRateLabel);
        inputPanel.add(premiumInterestRateField);
        inputPanel.add(numberYearsLabel);
        inputPanel.add(numberYearsField);
        inputPanel.add(new JLabel());
        inputPanel.add(submitButton);

        // Add the input panel and the scroll 
        mainFrame.add(inputPanel, BorderLayout.NORTH);
        mainFrame.add(scrollPane, BorderLayout.CENTER);

        mainFrame.setVisible(true);
    }
}
